function CalcularMercado(){
    var secos = document.getElementById("secos");
    var Divsecos = document.getElementById("Divsecos");

    var molhados = document.getElementById("molhados");
    var Divmolhados = document.getElementById("Divmolhados");

    var frageis = document.getElementById("frageis");
    var Divfrageis = document.getElementById("Divfrageis");

    var divsecos, divmolhados, divfrageis;

    var name = 0;
    name = prompt("Informe o nome e sobrenome: ");
    
    if (name.length < 5){
        alert("Nome inválido");
    }
    
    else if (secos.value == "" | molhados.value == "" | frageis.value == "" ){
        alert("Algum campo está em branco. \nInforme o valor para continuar.");
    }

    else  {
        divsecos = Math.round(Divsecos.value / secos.value);
        divmolhados = Math.round(Divmolhados.value / molhados.value);
        divfrageis = Math.round(Divfrageis.value / frageis.value);

        alert("Quantidade de sacolas que o cliente Sr. " + name + " precisa é de: \n" +
            "Itens secos: " + divsecos + " sacolas \n" +
            "Itens molhados: " + divmolhados + " sacolas \n" +
            "Itens frágeis: " + divfrageis + " sacolas");
    }
   
}    

function MudarCor(i){
    var elemento = document.getElementById("cor1");
    if (i == 1){
        elemento.style.backgroundColor = "blue";
    }
    else if (i == 2){
        elemento.style.backgroundColor = "rgb(228, 226, 226)";
    }
}

function MudarCor1(i){
    var elemento = document.getElementById("cor2");
    if (i == 1){
        elemento.style.backgroundColor = "yellow";
    }
    else if (i == 2){
        elemento.style.backgroundColor = "rgb(228, 226, 226)"
    }
}

function MudarCor2(i){
    var elemento = document.getElementById("cor3");
    if (i == 1){
        elemento.style.backgroundColor = "green";
    }
    else if (i == 2){
        elemento.style.backgroundColor = "rgb(228, 226, 226)"
    }
}

setInterval(function(){
        $('.Supermercado').fadeOut(1000);
        $('.Supermercado').fadeIn(1000);
    }, 1000);

